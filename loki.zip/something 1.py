from flask import Flask, render_template
from pymongo import MongoClient

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['language_tutoring']
teachers_collection = db['teachers']

# Sample teacher data
teachers = [
    {"name": "Teacher Name 1", "gmeet_id": "teacher1@gmail.com"},
    {"name": "Teacher Name 2", "gmeet_id": "teacher2@gmail.com"},
    {"name": "Teacher Name 3", "gmeet_id": "teacher3@gmail.com"}
    # Add more teachers as needed
]

# Function to generate genuine Google Meet link
def generate_meet_link(gmeet_id):
    # You would typically generate this link dynamically based on your authentication and access control logic
    # For demonstration purposes, we're just returning a static link here
    return f"https://meet.google.com/{gmeet_id}"

@app.route('/')
def index():
    return render_template('index.html', teachers=teachers, generate_meet_link=generate_meet_link)

if __name__ == '__main__':
    app.run(debug=True)
